using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine.SceneManagement;

public static class OpenGameScene
{
    const string GameScene = "Assets/Scenes/Game.unity";

    [InitializeOnLoadMethod]
    static void OpenWhenProjectStartsEmpty()
    {
        EditorApplication.delayCall += () =>
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode || UnityEngine.Application.isBatchMode)
                return;
            Scene current = SceneManager.GetActiveScene();
            // A fresh Unity project may open an empty Untitled scene. Open the
            // supplied game in that case, without replacing any saved or edited scene.
            if (string.IsNullOrEmpty(current.path) && !current.isDirty)
                EditorSceneManager.OpenScene(GameScene);
        };
    }

    [MenuItem("Game/Open Game Scene")]
    public static void Open()
    {
        if (EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())
            EditorSceneManager.OpenScene(GameScene);
    }
}
