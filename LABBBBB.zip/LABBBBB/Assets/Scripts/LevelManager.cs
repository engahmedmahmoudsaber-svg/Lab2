using UnityEngine;

public class LevelManager : MonoBehaviour
{
    public GameObject CurrentCheckpoint;

    void Start()
    {
        CurrentCheckpoint = null;
    }

    public void RespawnPlayer()
    {
        if (CurrentCheckpoint != null)
        {
            SimplePlayer player = FindObjectOfType<SimplePlayer>();

            if (player != null)
            {
                player.transform.position = CurrentCheckpoint.transform.position;
            }
        }
    }
}