using UnityEngine;

[RequireComponent(typeof(Rigidbody2D), typeof(BoxCollider2D), typeof(Animator))]
public class SimplePlayer : MonoBehaviour
{
    public float moveSpeed = 5f;
    public float jumpSpeed = 8f;
    public LayerMask groundLayer = 1 << 3;
    public BoxCollider2D platform;

    Rigidbody2D body;
    BoxCollider2D feet;
    Animator animator;
    SpriteRenderer sprite;
    Vector3 startPosition;
    float horizontal;
    bool jumpRequested;
    bool grounded;
    readonly RaycastHit2D[] groundHits = new RaycastHit2D[4];
    ContactFilter2D groundFilter;

    void Awake()
    {
        body = GetComponent<Rigidbody2D>();
        feet = GetComponent<BoxCollider2D>();
        animator = GetComponent<Animator>();
        sprite = GetComponent<SpriteRenderer>();
        startPosition = transform.position;
        body.freezeRotation = true;
        body.interpolation = RigidbodyInterpolation2D.Interpolate;
        body.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
        groundFilter = new ContactFilter2D();
        groundFilter.SetLayerMask(groundLayer);
        groundFilter.useTriggers = false;
    }

    void Update()
    {
        // Direct key input keeps the project independent of input action assets.
        horizontal = 0f;
        if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow)) horizontal -= 1f;
        if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow)) horizontal += 1f;
        if (Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.UpArrow))
            jumpRequested = true;
        if (Input.GetKeyDown(KeyCode.R)) Restart();

        if (horizontal != 0f) sprite.flipX = horizontal < 0f;
        animator.SetFloat("Speed", Mathf.Abs(body.velocity.x));
        animator.SetFloat("Height", body.velocity.y);
        animator.SetBool("Grounded", grounded);
    }

    void FixedUpdate()
    {
        if (body.position.y < -8f)
        {
            Restart();
            return;
        }

        grounded = false;
        if (body.velocity.y <= 0.05f)
        {
            int count = feet.Cast(Vector2.down, groundFilter, groundHits, 0.04f);
            for (int i = 0; i < count; i++)
                if (groundHits[i].normal.y > 0.5f) grounded = true;
        }

        Vector2 velocity = body.velocity;
        velocity.x = horizontal * moveSpeed;
        if (platform != null)
        {
            // Keep the entire player collider on the platform, including while
            // jumping. Physical end walls also protect the level boundaries.
            float halfWidth = feet.bounds.extents.x + 0.02f;
            float left = platform.bounds.min.x + halfWidth;
            float right = platform.bounds.max.x - halfWidth;
            float nextX = body.position.x + velocity.x * Time.fixedDeltaTime;
            velocity.x = (Mathf.Clamp(nextX, left, right) - body.position.x)
                / Time.fixedDeltaTime;
        }
        if (jumpRequested && grounded)
        {
            velocity.y = jumpSpeed;
            grounded = false;
        }
        jumpRequested = false;
        body.velocity = velocity;
    }

    void Restart()
    {
        body.velocity = Vector2.zero;
        body.position = startPosition;
        transform.position = startPosition;
        horizontal = 0f;
        jumpRequested = false;
        grounded = false;
        if (Camera.main != null)
        {
            SimpleCameraFollow follow = Camera.main.GetComponent<SimpleCameraFollow>();
            if (follow != null) follow.Snap();
        }
    }
}
