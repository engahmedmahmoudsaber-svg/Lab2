using UnityEngine;

[RequireComponent(typeof(Camera))]
public class SimpleCameraFollow : MonoBehaviour
{
    public Transform player;
    public float smoothTime = 0.12f;
    public Vector3 offset = new Vector3(0f, 1.5f, -10f);
    public BoxCollider2D platform;
    public SpriteRenderer sky;
    Vector3 velocity;
    Camera view;

    void Awake()
    {
        view = GetComponent<Camera>();
    }

    void Start()
    {
        Snap();
    }

    void LateUpdate()
    {
        if (player == null) return;
        transform.position = Constrain(Vector3.SmoothDamp(transform.position, Destination(),
            ref velocity, smoothTime));
        FitSky();
    }

    Vector3 Destination()
    {
        Vector3 position = player.position + offset;
        position.y = Mathf.Max(2f, position.y);
        position.z = -10f;
        return Constrain(position);
    }

    Vector3 Constrain(Vector3 position)
    {
        if (platform == null || view == null) return position;
        float halfWidth = view.orthographicSize * view.aspect;
        float left = platform.bounds.min.x + halfWidth;
        float right = platform.bounds.max.x - halfWidth;
        position.x = left <= right ? Mathf.Clamp(position.x, left, right)
            : platform.bounds.center.x;
        return position;
    }

    void FitSky()
    {
        if (sky == null || sky.sprite == null || view == null) return;
        Vector2 size = sky.sprite.bounds.size;
        float height = view.orthographicSize * 2f + 0.1f;
        sky.transform.position = transform.position + Vector3.forward * 11f;
        sky.transform.localScale = new Vector3(height * view.aspect / size.x,
            height / size.y, 1f);
    }

    public void Snap()
    {
        if (player == null) return;
        velocity = Vector3.zero;
        transform.position = Destination();
        FitSky();
    }
}
